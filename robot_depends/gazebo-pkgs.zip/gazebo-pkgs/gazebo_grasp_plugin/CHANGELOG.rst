^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gazebo_grasp_plugin
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.2 (2018-01-06)
------------------
* Merge branch jacknlliu-fix-c11-error
* fix build error with c++ 11
* Contributors: Jack Liu, Jennifer Buehler

1.0.1 (2016-06-08)
------------------
* Fixed cmake files for jenkins builds
* Contributors: Jennifer Buehler

1.0.0 (2016-06-07)
------------------
* Initial release
* Contributors: Jennifer Buehler
